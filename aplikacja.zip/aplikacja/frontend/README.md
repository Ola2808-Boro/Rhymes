# RhymesGenerator

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 16.2.0.

## Uruchamianie aplikacji

Aby uruchomić aplikację, należy przejść do folderu `backend` i uruchomić plik app.py poleceniem `py app.py`.

## Budowanie najnowszej wersji front-endu

Aby zbudować najnowszą wersję front-endu, należy przejść do folderu `frontend` i wykonać polecenie `ng build`.
