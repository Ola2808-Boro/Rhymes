import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { CustomComponentsModule } from './custom-components/custom-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BusyConfig, NgBusyModule } from 'ng-busy';
import { CustomBusyComponent } from './custom-components/custom-busy/custom-busy.component';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    CustomComponentsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    NgBusyModule.forRoot(new BusyConfig({
      backdrop: true,
      template: CustomBusyComponent,
      delay: 200,
      minDuration: 600,
    }))],
  bootstrap: [AppComponent]
})
export class AppModule { }
