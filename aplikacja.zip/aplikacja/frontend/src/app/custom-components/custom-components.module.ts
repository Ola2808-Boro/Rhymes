import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomInputModule } from './custom-input/custom-input.module';
import { CustomSliderModule } from './custom-slider/custom-slider.module';
import { CustomCheckboxModule } from './custom-checkbox/custom-checkbox.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CustomInputModule,
    CustomSliderModule,
    CustomCheckboxModule,
  ],
  exports: [
    CustomInputModule,
    CustomSliderModule,
    CustomCheckboxModule
  ]
})
export class CustomComponentsModule { }
