import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'custom-busy',
  templateUrl: './custom-busy.component.html',
  styleUrls: ['./custom-busy.component.scss']
})

export class CustomBusyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
}
