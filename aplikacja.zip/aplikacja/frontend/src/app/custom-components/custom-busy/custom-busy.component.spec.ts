import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomBusyComponent } from './custom-busy.component';

describe('BusyComponent', () => {
  let component: CustomBusyComponent;
  let fixture: ComponentFixture<CustomBusyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CustomBusyComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(CustomBusyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
