import { ChangeDetectorRef, Component, Input, forwardRef } from '@angular/core';
import { FormControl, NG_VALUE_ACCESSOR } from '@angular/forms';
import { Options } from 'ngx-slider-v2';

@Component({
  selector: 'custom-slider',
  templateUrl: './custom-slider.component.html',
  styleUrls: ['./custom-slider.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => CustomSliderComponent),
      multi: true
    }
  ]
})
export class CustomSliderComponent {
  @Input() disabled = false;
  @Input() floor!: number;
  @Input() ceil!: number;
  @Input() step!: number;
  @Input() control!: FormControl;

  disabledCheckbox = { name: 'Uwzględnij wszystkie wartości', checked: true }

  value: any;
  options: Options = {
    showTicks: true,
  };

  constructor(
    private changeDetector: ChangeDetectorRef
  ) { }


  ngOnInit() {
    const newOptions: Options = Object.assign({}, this.options);
    newOptions.floor = this.floor;
    newOptions.ceil = this.ceil;
    newOptions.step = this.step;
    newOptions.disabled = this.disabled
    this.options = newOptions;

    if (this.control && this.disabled) {
      this.control.disable({ onlySelf: true })
    }
  }

  onChange: any = () => { };
  onTouched: any = () => { };

  writeValue(value: any): void {
    this.value = value;
    this.changeDetector.detectChanges();
  }

  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  updateValue(event: any): void {
    this.onChange(event);
  }

  setDisabledState(isDisabled: boolean) {
    if (isDisabled) {
      this.disabled = isDisabled;
    }
  }

  onDisabledChange() {
    const newOptions: Options = Object.assign({}, this.options);
    newOptions.disabled = this.disabled
    this.options = newOptions;
    this.disabled ? this.control.disable({ onlySelf: true }) : this.control.enable({ onlySelf: true })
  }
}
