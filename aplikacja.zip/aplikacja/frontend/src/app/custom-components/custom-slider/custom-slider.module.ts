import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomSliderComponent } from './custom-slider.component';
import { NgxSliderModule } from 'ngx-slider-v2';
import { FormsModule } from '@angular/forms';
import { CustomCheckboxModule } from '../custom-checkbox/custom-checkbox.module';



@NgModule({
  declarations: [
    CustomSliderComponent
  ],
  imports: [
    CommonModule,
    NgxSliderModule,
    FormsModule,
    CustomCheckboxModule
  ],
  exports: [CustomSliderComponent]
})
export class CustomSliderModule { }
