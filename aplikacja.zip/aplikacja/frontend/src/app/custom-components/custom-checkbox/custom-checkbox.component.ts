import { ChangeDetectorRef, Component, Input, forwardRef } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'custom-checkbox',
  templateUrl: './custom-checkbox.component.html',
  styleUrls: ['./custom-checkbox.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => CustomCheckboxComponent),
      multi: true
    }
  ]
})
export class CustomCheckboxComponent {
  @Input() id: string | undefined;
  @Input() valid: boolean = true;
  @Input() item: any;
  @Input() disabled: any;
  value: any;

  constructor(
    private changeDetector: ChangeDetectorRef
  ) { }

  onChange: any = () => { };
  onTouched: any = () => { };

  ngOnInit() {
    if (this.item.checked) this.value = this.item.checked
  }

  click() {
    this.value = !this.value;
    this.item.checked = this.value;
    this.onChange(this.value);
  }

  writeValue(value: any) {
    this.value = value;
    this.changeDetector.detectChanges();
  }

  registerOnChange(fn: any) {
    this.onChange = fn;
  }

  registerOnTouched(fn: any) {
    this.onTouched = fn;
  }

  updateValue(event: Event): void {
    this.value = event ? true : null;
    this.item.checked = this.value;
    this.onChange(this.value);
  }

  setDisabledState(isDisabled: boolean) {
    this.disabled = isDisabled;
  }
}
