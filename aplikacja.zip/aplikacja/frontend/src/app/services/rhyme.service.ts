import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, catchError, of, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RhymeService {
  baseUrl = 'http://127.0.0.1:5000'

  constructor(private http: HttpClient) { }

  getRhymes(params: any): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/rhymes`, { params }).pipe(
      map(response => {
        return response;
      }),
      catchError(error => {
        return of(error.error);
      })
    );
  }
}
