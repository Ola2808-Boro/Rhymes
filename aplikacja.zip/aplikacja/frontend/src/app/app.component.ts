import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { RhymeService } from './services/rhyme.service';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  quality = { floor: 0.1, ceil: 1, step: 0.1 }
  syllables_count = { floor: 1, ceil: 15, step: 1 }
  rhymes: Array<any> = []

  form = this.formBuilder.group({
    word: [null, Validators.required],
    quality: [null, Validators.required],
    syllables_count: [null, Validators.required]
  })

  sendingForm: boolean = false;
  public rhymeSub!: Subscription;

  constructor(
    private formBuilder: FormBuilder,
    private rhymeService: RhymeService,
    private toastr: ToastrService) { }

  isControlValid(controlName: string) {
    return !this.sendingForm || !(this.form.get(controlName)?.invalid && (this.form.get(controlName)?.dirty || this.form.get(controlName)?.touched))
  }

  getRhymes() {
    this.sendingForm = true;
    if (this.form.valid) {
      const params = this.form.value;
      this.rhymeSub = this.rhymeService.getRhymes(params).subscribe(
        (response: any) => {
          if (response && response.type !== 'error') {
            this.rhymes = response;
          } else {
            this.toastr.error(response.status ?? 'Błąd połączenia z serwerem');
          }
        }),
        (error: any) => {
          this.toastr.error(error);
        }
      this.sendingForm = false;
    } else {
      Object.keys(this.form.controls).forEach((key) => {
        this.form?.get(key)?.markAsTouched();
      });
      this.toastr.warning('Nie wypełniono wszystkich wymaganych pól')
    }
  }

  ngOnDestroy() {
    if (this.rhymeSub) this.rhymeSub.unsubscribe()
  }
}